package com.example.demo.customer.consoleController;

import com.example.demo.customer.model.classModels.GigUserOperations;
import com.example.demo.customer.model.classModels.TicketProcessor;
import com.example.demo.customer.model.objectModels.AccountModel;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;

public class UserGigController {
    public void start(AccountModel accountModel) throws SQLException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        boolean run = true; // Set up a flag to control the loop
        while (run) { // Start the while loop
            try {
                GigUserOperations.showAllGig();
                System.out.println("=====================================");
                System.out.println("Sundayag Gig Ticket Page");
                System.out.println("[1] Buy a gig ticket ");
                System.out.println("[2] Delete a gig ticket");
                System.out.println("[3] Go back to main menu");
                System.out.print("Enter a number: ");
                int userChoice = UserMainMenu.readChoice(reader);

                if (userChoice == 1) {
                    System.out.println("Please enter the artist of the gig you want to buy");
                    String artistName = reader.readLine();
                    boolean gigFound = false;
                    while (!gigFound) {
                        gigFound = GigUserOperations.findIfThereIsAGig(artistName);
                        if (!gigFound) {
                            System.out.println("There was no gig with that name. Please enter a valid gig name: ");
                            artistName = reader.readLine();
                        }
                    }
                    GigUserOperations.buyGig(artistName, accountModel);
                } else if (userChoice == 2) {
                    System.out.println("Please enter the Artist name of your ticket to be deleted: ");
                    System.out.println("[A LIST WILL BE SHOWN YOUR BOUGHT TICKETS] ");

                    TicketProcessor.fetchAllticketGigOfUser(accountModel);
                    System.out.println("Please enter the ticket Number of your ticket to be deleted: ");
                    int ticketNumber = Integer.parseInt(reader.readLine());
                    boolean success = TicketProcessor.deleteTicket(ticketNumber);
                    if (success) {
                        System.out.println("your tickets has been deleted: ");
                    } else {
                        System.out.println("sorry you have not deleted your ticket");
                    }
                } else if (userChoice == 3) {
                    run = false; // Exit the loop if the user chooses option 3
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private static void showGigs()
    {
        System.out.println("Viewing gigs...");
    }
}