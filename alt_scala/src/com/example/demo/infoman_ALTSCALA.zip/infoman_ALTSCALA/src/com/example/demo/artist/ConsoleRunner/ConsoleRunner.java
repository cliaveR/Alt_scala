package com.example.demo.artist.ConsoleRunner;

import com.example.demo.artist.ConsoleRunnerArtist.ConsoleAccountCreation;
import com.example.demo.artist.model.AccountModel;

import java.sql.SQLException;

public class ConsoleRunner {
    public static void main(String[] args) throws SQLException {
        ConsoleAccountCreation consoleAccountCreation = new ConsoleAccountCreation();
        consoleAccountCreation.start(new AccountModel());
    }
}
