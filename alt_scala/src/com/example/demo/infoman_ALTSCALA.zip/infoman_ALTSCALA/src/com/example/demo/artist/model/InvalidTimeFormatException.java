package com.example.demo.artist.model;

public class InvalidTimeFormatException extends Exception {
}
