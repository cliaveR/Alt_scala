package com.example.demo.customer.model.objectModels;

public class TransactionModel
{

    private int transactionId;

    private int userId;

    public String paymentMethod;

    private String fullName;

    private String email;

    private int ticketAmount;

    private double transactionAmount;
    private String discountCode;
    private String phoneNumber;



    public String getDiscountCode() {
        return discountCode;
    }

    public void setDiscountCode(String discountCode) {
        this.discountCode = discountCode;
    }

    public TransactionModel(int transactionId, int userId, String paymentMethod, String fullName, String email, int ticketAmount, double transactionAmount, String discountCode, String phoneNumber) {
        this.transactionId = transactionId;
        this.userId = userId;
        this.paymentMethod = paymentMethod;
        this.fullName = fullName;
        this.email = email;
        this.ticketAmount = ticketAmount;
        this.transactionAmount = transactionAmount;
        this.discountCode = discountCode;
        this.phoneNumber = phoneNumber;
    }

    public int getUserId() {
        return userId;
    }

    public TransactionModel(int transactionId, int userId, String paymentMethod, String fullName, String phoneNumber, String email, int ticketAmount, double transactionAmount) {
        this.transactionId = transactionId;
        this.userId = userId;
        this.paymentMethod = paymentMethod;
        this.fullName = fullName;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.ticketAmount = ticketAmount;
        this.transactionAmount = transactionAmount;
    }


    public TransactionModel() {
    }


    public TransactionModel(int transactionId, String paymentMethod, String fullName, String phoneNumber, String email, int ticketAmount, double transactionAmount) {
        this.transactionId = transactionId;
        this.paymentMethod = paymentMethod;
        this.fullName = fullName;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.ticketAmount = ticketAmount;
        this.transactionAmount = transactionAmount;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public int getTransactionId() {
        return transactionId;
    }

    public String getFullName() {
        return fullName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public int getTicketAmount() {
        return ticketAmount;
    }

    public double getTransactionAmount() {
        return transactionAmount;
    }
}
