package com.example.demo.artist.model;

public class InvalidDateFormatException extends Exception {
}
