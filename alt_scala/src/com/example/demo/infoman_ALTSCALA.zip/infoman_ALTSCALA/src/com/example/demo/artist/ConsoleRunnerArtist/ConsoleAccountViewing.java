package com.example.demo.artist.ConsoleRunnerArtist;

import com.example.demo.artist.model.AccountDAO;
import com.example.demo.artist.model.AccountModel;

import java.sql.SQLException;
import java.util.Scanner;

public class ConsoleAccountViewing {
    private Scanner scanner;

    public void start(AccountModel account) throws SQLException {
        scanner = new Scanner(System.in);

        System.out.println("Viewing Account Information");
        System.out.println(account);
        System.out.println("1. Edit Account Information");
        System.out.println("2. Delete Account");
        System.out.println("3. Log out");
        System.out.println("4. Go Back");

        System.out.print("Enter your choice: ");
        String choiceStr = scanner.nextLine();

        try {
            int choice = Integer.parseInt(choiceStr);

            switch (choice) {
                case 1:
                    editAccountInfo(account);
                    break;
                case 2:
                    deleteAccount(account);
                    break;
                case 3:
                    ConsoleAccountCreation consoleAccountCreation = new ConsoleAccountCreation();
                    consoleAccountCreation.start(account);
                    break;
                case 4:
                    ConsoleMainMenu consoleMainMenu = new ConsoleMainMenu();
                    consoleMainMenu.start(account);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a number.");
        }
    }



    private void editAccountInfo(AccountModel account) throws SQLException {
        System.out.println("Editing Account Information");
        System.out.println("You are only able to edit your username and email address");
        System.out.println("1. Edit username");
        System.out.println("2. Edit email Address");
        System.out.println("3. Go back");

        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                System.out.print("Enter new username: ");
                String newUsername = scanner.nextLine();
                account.setUsername(newUsername);
                break;
            case 2:
                System.out.print("Enter new email address");
                String newEmailAddress = scanner.nextLine();
                account.setEmailAddress(newEmailAddress);
                break;

            case 3:
                ConsoleMainMenu consoleMainMenu = new ConsoleMainMenu();
                consoleMainMenu.start(account);
               return;

            default:
                System.out.println("Invalid choice. Please try again. ");
                return;
        }

        AccountDAO.updateAccountInfo(account); // Assuming you have a method in AccountDAO to update account info
        System.out.println("Account information updated successfully!");
    }


    private void deleteAccount(AccountModel account) throws SQLException {
        System.out.println("Deletion of Account");
        System.out.print("Are you sure you want to delete this account? (y/n): ");
        String decision = scanner.nextLine();
        if (decision.equalsIgnoreCase("y")) {
            try {
                AccountDAO.deleteAccount(account);
                System.out.println("Account deleted successfully.");
                ConsoleAccountCreation consoleAccountCreation = new ConsoleAccountCreation();
                consoleAccountCreation.start(account);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }


        } else if (decision.equalsIgnoreCase("n")) {
            System.out.println("Account deletion cancelled.");
        } else {
            System.out.println("Invalid input. Please enter 'y' to confirm deletion or 'n' to cancel.");
            // Optionally, you might want to add additional logic to handle invalid input
        }
    }
}